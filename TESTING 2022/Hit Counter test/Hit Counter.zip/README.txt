by J16D
To turn on/off type as a cheat: YT